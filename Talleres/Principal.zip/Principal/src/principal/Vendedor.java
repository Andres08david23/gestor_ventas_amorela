package principal;

public class Vendedor {
   
    private String documento;
    private int tipoVendedor; 
    private double valorVentas;

   
    public Vendedor(String documento, int tipoVendedor, double valorVentas) {
        this.documento = documento;
        this.tipoVendedor = tipoVendedor;
        this.valorVentas = valorVentas;
    }

    
    public String getDocumento() {
        return documento;
    }

    public void setDocumento(String documento) {
        this.documento = documento;
    }

    public int getTipoVendedor() {
        return tipoVendedor;
    }

    public void setTipoVendedor(int tipoVendedor) {
        this.tipoVendedor = tipoVendedor;
    }

    public double getValorVentas() {
        return valorVentas;
    }

    public void setValorVentas(double valorVentas) {
        this.valorVentas = valorVentas;
    }

    // Método para calcular la comisión
    public double calcularComision() {
        switch (tipoVendedor) {
            case 1:
               
                return valorVentas * 0.25;
            case 2:
              
                return valorVentas * 0.20;
            default:
                return 0;
        }
    }
}
