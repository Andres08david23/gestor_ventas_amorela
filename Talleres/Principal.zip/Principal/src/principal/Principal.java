package principal;

import java.util.Scanner;

public class Principal {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        
        System.out.print("Ingrese documento del vendedor: ");
        String documento = sc.nextLine();

        System.out.print("Ingrese tipo de vendedor (1 = Puerta a Puerta, 2 = Telemercadeo): ");
        int tipo = sc.nextInt();

        System.out.print("Ingrese valor de las ventas del mes: ");
        double ventas = sc.nextDouble();

        
        Vendedor vendedor = new Vendedor(documento, tipo, ventas);

        
        double comision = vendedor.calcularComision();

        
        System.out.println("\n--- LIQUIDACIÓN DE COMISIÓN ---");
        System.out.println("Documento: " + vendedor.getDocumento());
        System.out.println("Tipo de vendedor: " + vendedor.getTipoVendedor());
        System.out.println("Valor de ventas: $" + vendedor.getValorVentas());
        System.out.println("Comisión a pagar: $" + comision);
    }
}
